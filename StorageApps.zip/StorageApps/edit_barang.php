<?php
session_start();

// Cek apakah pengguna sudah login dan role-nya admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit();
}

// Koneksi ke database
$conn = new mysqli('localhost', 'root', '', 'db_penyimpanan');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Ambil data barang berdasarkan ID
if (isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("SELECT * FROM barang WHERE id_barang = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    
    if (!$row) {
        $_SESSION['alert'] = [
            'type' => 'danger',
            'message' => 'Barang tidak ditemukan!'
        ];
        header("Location: dashboard.php");
        exit();
    }
}

// Proses update barang
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_barang'])) {
    $id = (int)$_POST['id'];
    $nama = $conn->real_escape_string($_POST['nama']);
    $jenis = $conn->real_escape_string($_POST['jenis']);
    $stok = (int)$_POST['stok'];

    // Validasi input
    if (!empty($nama) && !empty($jenis) && $stok >= 0) {
        $stmt = $conn->prepare("UPDATE barang SET nama_barang=?, jenis_barang=?, stok=? WHERE id_barang=?");
        $stmt->bind_param("ssii", $nama, $jenis, $stok, $id);
        
        if ($stmt->execute()) {
            $_SESSION['alert'] = [
                'type' => 'success', 
                'message' => 'Barang berhasil diperbarui!'
            ];
            header("Location: dashboard.php");
            exit();
        } else {
            $_SESSION['alert'] = [
                'type' => 'danger',
                'message' => 'Error: ' . $stmt->error
            ];
        }
        $stmt->close();
    } else {
        $_SESSION['alert'] = [
            'type' => 'warning',
            'message' => 'Semua field harus diisi dan stok tidak boleh negatif'
        ];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Barang</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            display: flex;
            margin: 0;
            flex-direction: column;
            background-color: #f8f9fa;
        }
        .content {
            flex: 1;
            padding: 80px 40px 20px;
        }
        .form-container {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .form-header {
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }
        .form-footer {
            border-top: 1px solid #eee;
            padding-top: 20px;
            margin-top: 25px;
        }
        .form-label {
            font-weight: 500;
            margin-bottom: 5px;
        }
        .form-control {
            padding: 10px 15px;
            border-radius: 5px;
        }
        .btn-submit {
            padding: 10px 20px;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <!-- Konten Utama -->
    <div class="content" id="content">
        <div class="form-container">
            <div class="form-header">
                <h2 class="mb-0">
                    <i class="fas fa-edit me-2"></i>
                    Edit Data Barang
                </h2>
                <p class="text-muted mb-0">
                    Perbarui informasi barang yang ada
                </p>
            </div>
            
            <?php if (isset($_SESSION['alert'])): ?>
                <div class="alert alert-<?= $_SESSION['alert']['type'] ?> alert-dismissible fade show">
                    <?= $_SESSION['alert']['message'] ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
                <?php unset($_SESSION['alert']); ?>
            <?php endif; ?>

            <form method="POST">
                <input type="hidden" name="id" value="<?= htmlspecialchars($row['id_barang']) ?>">
                
                <div class="mb-4">
                    <label for="nama" class="form-label">Nama Barang</label>
                    <input type="text" class="form-control" id="nama" name="nama" 
                           value="<?= htmlspecialchars($row['nama_barang']) ?>" 
                           required>
                </div>
                
                <div class="mb-4">
                    <label for="jenis" class="form-label">Jenis Barang</label>
                    <input type="text" class="form-control" id="jenis" name="jenis" 
                           value="<?= htmlspecialchars($row['jenis_barang']) ?>" 
                           required>
                </div>
                
                <div class="mb-4">
                    <label for="stok" class="form-label">Stok</label>
                    <input type="number" class="form-control" id="stok" name="stok" 
                           value="<?= htmlspecialchars($row['stok']) ?>" 
                           min="0" required>
                </div>
                
                <div class="form-footer d-flex justify-content-between">
                    <button type="submit" name="update_barang" class="btn btn-primary btn-submit">
                        <i class="fas fa-save me-2"></i>
                        Simpan Perubahan
                    </button>
                    <a href="dashboard.php" class="btn btn-outline-secondary">
                        <i class="fas fa-arrow-left me-2"></i> Kembali
                    </a>
                </div>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Auto focus ke field pertama
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('nama').focus();
        });
        
        // Validasi form sebelum submit
        document.querySelector('form').addEventListener('submit', function(e) {
            const stok = document.getElementById('stok').value;
            if (stok < 0) {
                e.preventDefault();
                alert('Stok tidak boleh negatif');
            }
        });
    </script>
</body>
</html>