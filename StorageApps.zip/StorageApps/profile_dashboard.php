<?php
session_start();

// Aktifkan error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Cek apakah user sudah login
if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit();
}

// Koneksi ke database
$conn = new mysqli('localhost', 'root', '', 'db_penyimpanan');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// Hitung jumlah pending untuk notifikasi
$pending_count = $conn->query("SELECT COUNT(*) as count FROM barang WHERE status_verifikasi = 'pending'")->fetch_assoc()['count'];

// Ambil data user dari database
$user_id = $_SESSION['user_id'];
$query = "SELECT name, email FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("User tidak ditemukan");
}

$user = $result->fetch_assoc();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            display: flex;
            margin: 0;
            flex-direction: column;
        }
        .navbar {
            background: #1a2b3c;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            height: 60px;
        }
        .navbar h3 {
            margin: 0;
            order: 2;
        }
        .navbar .menu-toggle {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: white;
            order: 1;
        }
        .sidebar {
            width: 250px;
            height: calc(100vh - 60px);
            background: #1a2b3c;
            color: white;
            padding: 15px;
            transition: 0.3s;
            position: fixed;
            left: 0;
            top: 60px;
            z-index: 999;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 10px;
            display: flex;
            align-items: center;
        }
        .sidebar a:hover {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 5px;
        }
        .sidebar i {
            margin-right: 10px;
        }
        .sidebar.hidden {
            width: 0;
            padding: 0;
            overflow: hidden;
        }
        .content {
            flex: 1;
            padding: 80px 40px 20px;
            margin-left: 250px;
            transition: 0.3s;
        }
        .profile-container {
            max-width: 800px;
            margin: 0 auto;
            padding: 30px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
        }
        .profile-header {
            text-align: center;
            margin-bottom: 30px;
        }
        .profile-table {
            width: 100%;
            border-collapse: collapse;
        }
        .profile-table th {
            background-color: #f1f1f1;
            padding: 12px;
            text-align: left;
        }
        .profile-table td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        .profile-table tr:hover {
            background-color: #f5f5f5;
        }
        .notification-badge {
            background-color: red;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 12px;
            margin-left: 5px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <div class="navbar">
        <button class="menu-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <h4 class="mb-4">Menu</h4>
        <a href="profile_dashboard.php"><i class="fas fa-user"></i> Profil </a>
        <a href="dashboard.php"><i class="fas fa-database"></i> Kelola Barang </a>
        <a href="dashboard_verifikasi.php"><i class="fas fa-check-circle"></i> Verifikasi Stok
        <?php if ($pending_count > 0): ?>
                <span class="notification-badge"><?php echo $pending_count; ?></span>
            <?php endif; ?>
        </a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Keluar</a>
    </div>

    <!-- Konten Utama -->
    <div class="content" id="content">
        <div class="profile-container">
            <div class="profile-header">
                <h2><i class="fas fa-user-circle"></i> Profil Pengguna</h2>
                <p class="text-muted">Informasi akun Anda</p>
            </div>
            
            <table class="profile-table table">
                <thead>
                    <tr>
                        <th><i class="fas fa-id-card"></i> Nama</th>
                        <th><i class="fas fa-envelope"></i> Email</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?php echo htmlspecialchars($user['name']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                    </tr>
                </tbody>
            </table>
            
            <div class="text-center mt-4">
                <a href="edit_profile.php" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Edit Profil
                </a>
            </div>
        </div>
    </div>

    <script>
        // Fungsi untuk toggle sidebar
        function toggleSidebar() {
            const sidebar = document.getElementById("sidebar");
            const content = document.getElementById("content");
            sidebar.classList.toggle("hidden");
            content.style.marginLeft = sidebar.classList.contains("hidden") ? "0" : "250px";
        }
    </script>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>