<?php
session_start();

// Aktifkan error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Cek apakah pengguna sudah login dan role-nya admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php'); // Redirect ke halaman login jika bukan admin
    exit();
}

// Koneksi ke database
$conn = new mysqli('localhost', 'root', '', 'db_penyimpanan');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fungsi untuk menghapus barang
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM barang WHERE id_barang=$id") or die($conn->error);
    header("Location: dashboard.php"); // Redirect ke dashboard.php setelah berhasil
}

// Ambil data barang dengan fitur pencarian
$search = isset($_GET['search']) ? $_GET['search'] : '';
$query = "SELECT * FROM barang";
if (!empty($search)) {
    $query .= " WHERE nama_barang LIKE '%$search%'";
}
$result = $conn->query($query) or die($conn->error);

// AMBIL DATA BARANG DENGAN STATUS PENDING
$pending_count = $conn->query("SELECT COUNT(*) as count FROM barang WHERE status_verifikasi = 'pending'")->fetch_assoc()['count'];

// AMBIL SEMUA DATA BARANG
$search = $_GET['search'] ?? '';
$query = "SELECT 
    id_barang, 
    nama_barang, 
    jenis_barang, 
    stok, 
    stok_usulan,
    status_verifikasi,
    gambar
FROM barang";

          
if (!empty($search)) {
    $query .= " WHERE nama_barang LIKE CONCAT('%', ?, '%')";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $search);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = $conn->query($query);
}

if (!$result) {
    die("Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            display: flex;
            margin: 0;
            flex-direction: column;
        }
        .navbar {
            background: #1a2b3c;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            height: 60px;
        }
        .navbar h3 {
            margin: 0;
            order: 2;
        }
        .navbar .menu-toggle {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: white;
            order: 1;
        }
        .sidebar {
            width: 250px;
            height: calc(100vh - 60px);
            background: #1a2b3c;
            color: white;
            padding: 15px;
            transition: 0.3s;
            position: fixed;
            left: 0;
            top: 60px;
            z-index: 999;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 10px;
            display: flex;
            align-items: center;
        }
        .sidebar a:hover {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 5px;
        }
        .sidebar i {
            margin-right: 10px;
        }
        .sidebar.hidden {
            width: 0;
            padding: 0;
            overflow: hidden;
        }
        .content {
            flex: 1;
            padding: 80px 40px 20px;
            margin-left: 250px;
            transition: 0.3s;
        }
        .table th, .table td {
            vertical-align: middle;
            text-align: center;
        }
        .btn-action {
            width: 80px;
            margin: 2px;
        }
        .table-container {
            max-height: 500px;
            overflow-y: auto;
            margin-bottom: 20px;
        }
        .table-container::-webkit-scrollbar {
            width: 8px;
        }
        .table-container::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        .table-container::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }
        .table-container::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .notification-badge {
            background-color: red;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 12px;
            margin-left: 5px;
        }
        /* Style baru untuk alert notifikasi */
        .alert-notification {
            position: fixed;
            top: 70px;
            right: 20px;
            z-index: 1100;
            min-width: 300px;
            animation: slideIn 0.5s forwards;
        }
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <div class="navbar">
        <button class="menu-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <h4 class="mb-4">Menu</h4>
        <a href="profile_dashboard.php"><i class="fas fa-user"></i> Profil</a>
        <a href="dashboard.php"><i class="fas fa-database"></i> Kelola Barang</a>
        <a href="dashboard_verifikasi.php">
            <i class="fas fa-check-circle"></i> Verifikasi Stok
            <?php if ($pending_count > 0): ?>
                <span class="notification-badge"><?php echo $pending_count; ?></span>
            <?php endif; ?>
        </a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Keluar</a>
    </div>

    <!-- Konten Utama -->
    <div class="content" id="content">
        <h1 class="my-4">Kelola Barang</h1>
        <!-- Form Pencarian -->
        <form method="GET" action="" class="mb-3">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Cari berdasarkan nama barang" value="<?php echo $search; ?>">
                <button type="submit" class="btn btn-primary">Cari</button>
            </div>
        </form>
        <a href="tambah_barang.php" class="btn btn-primary mb-3">Tambah Barang</a>
        <!-- Container untuk tabel dengan scrollbar -->
        <div class="table-container">
            <table class="table table-bordered">
                <thead class="thead-light">
                    <tr>
                        <th class="text-center">ID Barang</th>
                        <th class="text-center">Nama Barang</th>
                        <th class="text-center">Jenis Barang</th>
                        <th class="text-center">Stok</th>
                        <th class="text-center">Gambar</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td class="text-center"><?php echo $row['id_barang']; ?></td>
                            <td class="text-center"><?php echo $row['nama_barang']; ?></td>
                            <td class="text-center"><?php echo $row['jenis_barang']; ?></td>
                            <td class="text-center"><?php echo $row['stok']; ?></td>
                            <td class="text-center">
                                <?php if (!empty($row['gambar'])): ?>
                                    <img src="uploads/<?php echo $row['gambar']; ?>" width="60" height="60" style="object-fit: cover;">
                                <?php else: ?>
                                    <span class="text-muted">Tidak ada</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <a href="edit_barang.php?id=<?php echo $row['id_barang']; ?>" class="btn btn-warning btn-sm btn-action">Edit</a>
                                <a href="dashboard.php?delete=<?php echo $row['id_barang']; ?>" class="btn btn-danger btn-sm btn-action">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <?php if (isset($_SESSION['alert'])): ?>
    <div class="alert alert-<?= $_SESSION['alert']['type'] ?> alert-notification alert-dismissible fade show">
        <?= $_SESSION['alert']['message'] ?>
        <button type="button" class="btn-close" onclick="closeAlert(this)"></button>
    </div>
    <?php unset($_SESSION['alert']); ?>
    <?php endif; ?>

    <!-- Script untuk toggle sidebar -->
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById("sidebar");
            const content = document.getElementById("content");
            sidebar.classList.toggle("hidden");
            content.style.marginLeft = sidebar.classList.contains("hidden") ? "0" : "250px";
        }
        
        function closeAlert(button) {
            const alert = button.closest('.alert');
            alert.style.animation = 'slideOut 0.5s forwards';
            setTimeout(() => alert.remove(), 500);
        }
        
        // Auto close alert setelah 5 detik
        document.addEventListener('DOMContentLoaded', function() {
            const alert = document.querySelector('.alert-notification');
            if (alert) {
                setTimeout(() => {
                    alert.style.animation = 'slideOut 0.5s forwards';
                    setTimeout(() => alert.remove(), 500);
                }, 5000);
            }
        });
    </script>

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>