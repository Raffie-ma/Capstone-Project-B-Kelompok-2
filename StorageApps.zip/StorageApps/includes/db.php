<?php
// Konfigurasi koneksi database
$host = 'localhost';      // Host database (biasanya localhost)
$db = 'db_penyimpanan';   // Nama database yang akan digunakan
$user = 'root';           // Username untuk mengakses database
$pass = '';               // Password untuk mengakses database

try {
    // Membuat koneksi PDO ke database MySQL
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    
    // Mengatur mode error PDO untuk menampilkan exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Catatan: Koneksi berhasil dibuat dan disimpan dalam variabel $pdo
    // Variabel $pdo ini bisa digunakan di file lain yang meng-include file ini
} catch (PDOException $e) {
    // Menangani error jika koneksi gagal
    die("Could not connect to the database $db :" . $e->getMessage());
    // Fungsi die() akan menghentikan eksekusi script dan menampilkan pesan error
}
?>