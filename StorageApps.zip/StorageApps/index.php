<?php
// Memulai session untuk menyimpan data user yang login
session_start();
// Menginclude file koneksi database
include 'includes/db.php';

// Memproses data jika form dikirim dengan metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];
    
    // Mempersiapkan query dengan prepared statement untuk mencegah SQL injection
    $stmt = $pdo->prepare("SELECT * FROM Users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    // Memverifikasi password yang diinput dengan hash di database
    if ($user && password_verify($password, $user['password'])) {
        // Menyimpan data user di session
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role'] = $user['role']; // Menyimpan role pengguna di session

        // Mengarahkan user berdasarkan role (admin/user)
        if ($user['role'] == 'admin') {
            header('Location: profile_dashboard.php');
        } else {
            header('Location: home_user.php');
        }
        exit(); // Menghentikan eksekusi script setelah redirect
    } else {
        $error = "Invalid email or password."; // Pesan error jika login gagal
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Menginclude library Bootstrap untuk styling -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/main/style.css"> <!-- CSS kustom -->
    <!-- Menginclude library JavaScript yang diperlukan -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.min.js"></script>
    <title>Login</title>
</head>
<body style="background-image: url('assets/images/background.jpg')">
    <!-- Container utama untuk form login -->
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="login-box">
            <h2>Welcome, Back!</h2>
            <!-- Form login dengan method POST -->
            <form method="POST" action="index.php">
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" class="form-control" name="password" placeholder="Enter your password" required>
                </div>
                <!-- Tombol submit untuk login -->
                <button type="submit" class="btn btn-warning btn-block">Login</button>
                <!-- Menampilkan pesan error jika ada -->
                <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
                <!-- Link ke halaman registrasi -->
                <a href="register.php" class="btn btn-secondary btn-block mt-2">Register</a>
            </form>
        </div>
    </div>
</body>
</html>