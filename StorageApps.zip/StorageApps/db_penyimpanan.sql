-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 06, 2025 at 07:09 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_penyimpanan`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL,
  `nama_barang` varchar(255) NOT NULL,
  `jenis_barang` varchar(255) NOT NULL,
  `stok` int(11) NOT NULL,
  `stok_usulan` int(11) DEFAULT NULL,
  `status_verifikasi` enum('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  `gambar` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `jenis_barang`, `stok`, `stok_usulan`, `status_verifikasi`, `gambar`) VALUES
(215, 'Penghapus', 'ATK', 8, NULL, 'approved', 'penghapus.png'),
(216, 'Penghapus Joyko', 'ATK', 1, NULL, 'approved', 'penghapus.png'),
(217, 'Penghapus Fabercastel', 'ATK', 10, NULL, 'approved', 'penghapus.png'),
(218, 'Penghapus Kenko', 'ATK', 100, NULL, 'approved', 'penghapus.png');

-- --------------------------------------------------------

--
-- Table structure for table `Users`
--

CREATE TABLE `Users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `Users`
--

INSERT INTO `Users` (`id`, `name`, `email`, `password`, `role`, `created_at`, `updated_at`) VALUES
(1, 'AdminUser', 'admin@gmail.com', '$2y$10$qK6F9HnhLzrGxEKVd5STiuHZq.KDQx04mmAzY9uzdWiytZvNgS0mK', 'admin', '2025-03-17 02:17:36', '2025-03-17 02:17:36'),
(2, 'Regular User', 'user@gmail.com', '$2y$10$QD3KeOu/KAn3ItZz2JlrhuB9RvPcIGV1w0XyEZ2ZYg7eHgn7CHvIm', 'user', '2025-03-17 03:17:01', '2025-03-17 03:30:19'),
(3, 'Dizzo', 'dizzo0607@gmail.com', '$2y$10$b6Sa9QccQ0w4/j3j8mxjJ.7Vwq0TPc6mbncaRFbSqbCsNbHTQXWDq', 'user', '2025-03-17 01:36:39', '2025-03-17 01:36:39'),
(4, 'user 101', 'dizzo@gmail.com', '$2y$10$yQHP3JXr3GXEuOZc.JRPhuilR93FiJx6G3wF14R9jn.hlJZOPhu46', 'user', '2025-03-17 19:23:41', '2025-03-17 19:23:41'),
(5, 'violeta', 'violeta@gmail.com', '$2y$10$9nhrAk1UcJDVsTTnpS6MCemkOuck5kvUiBJIxrgnjEUblL2rzxBnC', 'user', '2025-03-18 01:01:49', '2025-03-18 01:01:49');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=219;

--
-- AUTO_INCREMENT for table `Users`
--
ALTER TABLE `Users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
