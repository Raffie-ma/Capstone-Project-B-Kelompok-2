<?php
// Memulai session untuk menyimpan data user yang registrasi
session_start();
// Menginclude file koneksi database
include 'includes/db.php';

// Variabel untuk menyimpan pesan error
$error = "";

// Memproses data jika form dikirim dengan metode POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // Validasi kesesuaian password dan konfirmasi password
    if ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Memeriksa apakah email sudah terdaftar di database
        $stmt = $pdo->prepare("SELECT * FROM Users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if ($user) {
            $error = "Email already registered.";
        } else {
            // Meng-hash password sebelum disimpan ke database
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // Mendapatkan waktu saat ini untuk timestamp
            $current_time = date('Y-m-d H:i:s');

            // Menyimpan data user baru ke database dengan role default 'user'
            $stmt = $pdo->prepare("INSERT INTO Users (name, email, password, role, created_at, updated_at) VALUES (?, ?, ?, 'user', ?, ?)");
            $stmt->execute([$name, $email, $hashed_password, $current_time, $current_time]);

            // Mendapatkan ID user yang baru saja didaftarkan
            $user_id = $pdo->lastInsertId();

            // Set session untuk user yang baru registrasi (auto-login)
            $_SESSION['user_id'] = $user_id;
            $_SESSION['role'] = 'user'; // Set role default sebagai 'user'

            // Redirect ke halaman header.php setelah registrasi berhasil
            header('Location: header.php');
            exit(); // Menghentikan eksekusi script setelah redirect
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Menginclude library Bootstrap untuk styling -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/main/style.css"> <!-- CSS kustom -->
    <!-- Menginclude library JavaScript yang diperlukan -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.min.js"></script>
    <title>Register</title>
</head>
<body style="background-image: url('assets/images/background.jpg')">
    <!-- Container utama untuk form registrasi -->
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="login-box">
            <h2>Register</h2>
            <!-- Form registrasi dengan method POST -->
            <form method="POST" action="register.php">
                <div class="form-group">
                    <label for="name">Name:</label>
                    <input type="text" class="form-control" name="name" placeholder="Enter your name" required>
                </div>
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" class="form-control" name="email" placeholder="Enter your email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" class="form-control" name="password" placeholder="Enter your password" required>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password:</label>
                    <input type="password" class="form-control" name="confirm_password" placeholder="Confirm your password" required>
                </div>
                <!-- Tombol submit untuk registrasi -->
                <button type="submit" class="btn btn-warning btn-block">Register</button>
                <!-- Menampilkan pesan error jika ada -->
                <?php if(isset($error)) echo "<div class='alert alert-danger'>$error</div>"; ?>
                <!-- Link kembali ke halaman login -->
                <a href="index.php" class="btn btn-secondary btn-block mt-2">Back to Login</a>
            </form>
        </div>
    </div>
</body>
</html>