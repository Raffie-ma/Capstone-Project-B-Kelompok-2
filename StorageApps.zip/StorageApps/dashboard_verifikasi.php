<?php
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'admin') {
    header('Location: index.php');
    exit();
}

$conn = new mysqli('localhost', 'root', '', 'db_penyimpanan');
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

// PROSES VERIFIKASI
if (isset($_GET['approve'])) {
    $id = (int)$_GET['approve'];
    
    // 1. Ambil data stok
    $result = $conn->query("SELECT stok, stok_usulan FROM barang WHERE id_barang=$id");
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        // 2. Hitung stok baru
        $new_stock = $row['stok'] + $row['stok_usulan'];
        
        // 3. Update database
        $update = $conn->query("UPDATE barang SET 
                     stok=$new_stock, 
                     stok_usulan=NULL, 
                     status_verifikasi='approved' 
                     WHERE id_barang=$id");
        
        if ($update) {
            $_SESSION['alert'] = ['type' => 'success', 'message' => 'Stok berhasil disetujui!'];
        } else {
            $_SESSION['alert'] = ['type' => 'danger', 'message' => 'Gagal menyetujui stok: ' . $conn->error];
        }
    }
    header("Location: dashboard_verifikasi.php");
    exit();
}

// PROSES PENOLAKAN YANG DIPERBAIKI
if (isset($_GET['reject'])) {
    $id = (int)$_GET['reject'];
    
    // Validasi ID
    if ($id <= 0) {
        $_SESSION['alert'] = ['type' => 'danger', 'message' => 'ID barang tidak valid!'];
        header("Location: dashboard_verifikasi.php");
        exit();
    }
    
    // 1. Update status verifikasi tanpa mengubah stok
    $update = $conn->query("UPDATE barang SET 
                 stok_usulan=NULL, 
                 status_verifikasi='rejected' 
                 WHERE id_barang=$id");
    
    if ($update) {
        $_SESSION['alert'] = ['type' => 'danger', 'message' => 'Stok usulan berhasil ditolak!'];
    } else {
        $_SESSION['alert'] = ['type' => 'danger', 'message' => 'Gagal menolak stok: ' . $conn->error];
    }
    
    header("Location: dashboard_verifikasi.php");
    exit();
}

// Handle pencarian
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';
$search_condition = $search ? "AND nama_barang LIKE '%$search%'" : "";

// AMBIL DATA YANG PERLU DIVERIFIKASI
$pending = $conn->query("SELECT 
                        id_barang, 
                        nama_barang, 
                        stok, 
                        stok_usulan,
                        status_verifikasi,
                        gambar
                      FROM barang 
                      WHERE status_verifikasi = 'pending' $search_condition");

// Hitung jumlah pending untuk notifikasi
$pending_count = $conn->query("SELECT COUNT(*) as count FROM barang WHERE status_verifikasi = 'pending'")->fetch_assoc()['count'];

if (!$pending) {
    die("Error: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verifikasi Stok</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            display: flex;
            margin: 0;
            flex-direction: column;
        }
        .navbar {
            background: #1a2b3c;
            color: white;
            padding: 10px 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            height: 60px;
        }
        .navbar h3 {
            margin: 0;
            order: 2;
        }
        .navbar .menu-toggle {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: white;
            order: 1;
        }
        .sidebar {
            width: 250px;
            height: calc(100vh - 60px);
            background: #1a2b3c;
            color: white;
            padding: 15px;
            transition: 0.3s;
            position: fixed;
            left: 0;
            top: 60px;
            z-index: 999;
        }
        .sidebar a {
            color: white;
            text-decoration: none;
            padding: 10px;
            display: flex;
            align-items: center;
        }
        .sidebar a:hover {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 5px;
        }
        .sidebar i {
            margin-right: 10px;
        }
        .sidebar.hidden {
            width: 0;
            padding: 0;
            overflow: hidden;
        }
        .content {
            flex: 1;
            padding: 80px 40px 20px;
            margin-left: 250px;
            transition: 0.3s;
        }
        .table th, .table td {
            vertical-align: middle;
            text-align: center;
        }
        .btn-action {
            width: 80px;
            margin: 2px;
        }
        .table-container {
            max-height: 500px;
            overflow-y: auto;
            margin-bottom: 20px;
        }
        .table-container::-webkit-scrollbar {
            width: 8px;
        }
        .table-container::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        .table-container::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
        }
        .table-container::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .notification-badge {
            background-color: red;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 12px;
            margin-left: 5px;
        }
    </style>
</head>
<body>

    <!-- Navbar -->
    <div class="navbar">
        <button class="menu-toggle" onclick="toggleSidebar()">
            <i class="fas fa-bars"></i>
        </button>
    </div>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <h4 class="mb-4">Menu</h4>
        <a href="profile_dashboard.php"><i class="fas fa-user"></i> Profil</a>
        <a href="dashboard.php"><i class="fas fa-database"></i> Kelola Barang</a>
        <a href="dashboard_verifikasi.php">
            <i class="fas fa-check-circle"></i> Verifikasi Stok
            <?php if ($pending_count > 0): ?>
                <span class="notification-badge"><?php echo $pending_count; ?></span>
            <?php endif; ?>
        </a>
        <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Keluar</a>
    </div>

    <!-- Konten Utama -->
    <div class="content" id="content">
        <h1 class="my-4">Verifikasi Stok</h1>
        
        <!-- Form Pencarian -->
        <form method="GET" action="" class="mb-3">
            <div class="input-group">
                <input type="text" name="search" class="form-control" placeholder="Cari berdasarkan nama barang" value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit" class="btn btn-primary">Cari</button>
            </div>
        </form>
        
        <?php if (isset($_SESSION['alert'])): ?>
        <div class="alert alert-<?= $_SESSION['alert']['type'] ?> alert-dismissible fade show mb-3" role="alert">
            <?= $_SESSION['alert']['message'] ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <script>
            // Auto close alert after 5 seconds
            setTimeout(() => {
                const alert = document.querySelector('.alert');
                if (alert) alert.remove();
            }, 5000);
        </script>
        <?php unset($_SESSION['alert']); ?>
        <?php endif; ?>
        
        <!-- Tabel Verifikasi Stok -->
        <div class="table-container">
            <table class="table table-bordered">
                <thead class="thead-light">
                    <tr>
                        <th class="text-center">ID Barang</th>
                        <th class="text-center">Nama Barang</th>
                        <th class="text-center">Stok Saat Ini</th>
                        <th class="text-center">Gambar</th>
                        <th class="text-center">Stok Usulan</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($pending->num_rows > 0): ?>
                        <?php while ($row = $pending->fetch_assoc()): ?>
                            <tr>
                                <td class="text-center"><?php echo $row['id_barang']; ?></td>
                                <td class="text-center"><?php echo htmlspecialchars($row['nama_barang']); ?></td>
                                <td class="text-center"><?php echo $row['stok']; ?></td>
                                <td class="text-center">
                                <?php if (!empty($row['gambar'])): ?>
                                    <img src="uploads/<?php echo $row['gambar']; ?>" width="60" height="60" style="object-fit: cover;">
                                <?php else: ?>
                                    <span class="text-muted">Tidak ada</span>
                                <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo $row['stok_usulan'] ?? '0'; ?></td>
                                <td class="text-center">
                                    <span class="badge bg-<?php echo $row['status_verifikasi'] == 'pending' ? 'warning' : ($row['status_verifikasi'] == 'approved' ? 'success' : 'danger'); ?>">
                                        <?php echo $row['status_verifikasi']; ?>
                                    </span>
                                </td>
                                <td class="text-center">
                                    <a href="dashboard_verifikasi.php?approve=<?php echo $row['id_barang']; ?>" class="btn btn-success btn-sm btn-action">Setujui</a>
                                    <a href="dashboard_verifikasi.php?reject=<?php echo $row['id_barang']; ?>" class="btn btn-danger btn-sm btn-action" onclick="return confirm('Yakin ingin menolak stok usulan ini?')">Tolak</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">Tidak ada stok yang perlu diverifikasi</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Script untuk toggle sidebar -->
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById("sidebar");
            const content = document.getElementById("content");
            sidebar.classList.toggle("hidden");
            content.style.marginLeft = sidebar.classList.contains("hidden") ? "0" : "250px";
        }
    </script>

    <!-- jQuery dan Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script>
</body>
</html>